import Navigation from './Navigation';
import { render } from 'test-utils';

describe('Navigation tests', () => {
    it('renders the component', () => {
        render(<Navigation />);
    });
});
